package com.cookandroid.project_gimal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class SecondActivity extends Activity {


    public Button btnChange,btnSave,btnDel;
    public TextView dateText, textView3;
    public CalendarView calendarView;
    public EditText editText;
    public String str;
    public String readDay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second2);


        btnChange = (Button) findViewById(R.id.btn_Change);
        btnSave = (Button) findViewById(R.id.btn_Save);
        btnDel = (Button) findViewById(R.id.btn_Del);

        dateText = (TextView) findViewById(R.id.dateText);
        calendarView = (CalendarView) findViewById(R.id.calendarView2);


        editText = (EditText) findViewById(R.id.editTXT);
        textView3 = (TextView) findViewById(R.id.textView3);



        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {
                month += 1;
                dateText.setText(String.format("%d년 %d월 %d일", year, month, dayOfMonth));
                dateText.setVisibility(View.VISIBLE);
                textView3.setVisibility(View.VISIBLE);
                btnChange.setVisibility(View.VISIBLE);
                editText.setVisibility(View.INVISIBLE);
                btnDel.setVisibility(View.VISIBLE);
                btnSave.setVisibility(View.INVISIBLE);
                editText.setText("");
                checkDay(year, month, dayOfMonth);
            }
        });
       btnSave.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               saveDiary(readDay);
               str = editText.getText().toString();
               textView3.setText(str);
               textView3.setVisibility(View.VISIBLE);
               btnChange.setVisibility(View.VISIBLE);
               btnSave.setVisibility(View.INVISIBLE);
               btnDel.setVisibility(View.VISIBLE);
               editText.setVisibility(View.INVISIBLE);
               dateText.setVisibility(View.VISIBLE);
           }
       });
    }
    public void checkDay(int cyear, int cmonth, int cdayOfMonth) {

        readDay = "" + cyear + "-" + (cmonth + 1) + "" + "-" + cdayOfMonth + ".txt";
        FileInputStream fis;

        try {
            fis = openFileInput(readDay);

            byte[] fileData = new byte[fis.available()];
            fis.read(fileData);
            fis.close();

            str = new String(fileData);

            editText.setVisibility(View.INVISIBLE);
            textView3.setVisibility(View.VISIBLE);
            textView3.setText(str);
            btnSave.setVisibility(View.INVISIBLE);
            btnChange.setVisibility(View.VISIBLE);
            btnDel.setVisibility(View.VISIBLE);


            btnChange.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    editText.setVisibility(View.VISIBLE);
                    textView3.setVisibility(View.INVISIBLE);
                    editText.setText(str);
                    btnSave.setVisibility(View.VISIBLE);
                    btnChange.setVisibility(View.INVISIBLE);
                    btnDel.setVisibility(View.INVISIBLE);
                    textView3.setText(editText.getText());

                }

            });
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    textView3.setVisibility(View.INVISIBLE);
                    editText.setText("");
                    editText.setVisibility(View.INVISIBLE);
                    btnSave.setVisibility(View.INVISIBLE);
                    btnChange.setVisibility(View.VISIBLE);
                    btnDel.setVisibility(View.VISIBLE);
                    removeDiary(readDay);
                }
            });
            if ( textView3== null) {
                textView3.setVisibility(View.VISIBLE);
                dateText.setVisibility(View.VISIBLE);
                btnSave.setVisibility(View.INVISIBLE);
                btnChange.setVisibility(View.VISIBLE);
                btnDel.setVisibility(View.VISIBLE);
                editText.setVisibility(View.INVISIBLE);
            }
        }
             catch(Exception e)
            {
                e.printStackTrace();
            }

    }

    public void saveDiary(String readDay)
    {
        FileOutputStream fos;
        try
        {
            fos = openFileOutput(readDay, MODE_PRIVATE);
            String content = editText.getText().toString();
            fos.write((content).getBytes());
            fos.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public void removeDiary(String readDay)
    {
        FileOutputStream fos;
        try
        {
            fos = openFileOutput(readDay, MODE_PRIVATE);
            String content = "";
            fos.write((content).getBytes());
            fos.close();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}









